# Lab 6 — Sequential Game Show Circuit

**Course:** CDA 3201L, University of South Florida  
**Author:** Diezel Brown

## Overview

This project explores a two-contestant game show circuit using D flip-flops and combinational logic on a breadboard. The circuit is designed to store the first sampled contestant input and prevent later inputs from changing the result until reset.

I did not complete the circuit during the scheduled lab session. I continued working on the breadboard outside the lab and used an Arduino Uno to supply the clock signal in place of the lab function generator. The Arduino provides clock pulses; the external logic circuit implements the state storage and next-state logic.

## Intended behavior

- Reset clears both state bits and turns both LEDs off.
- From the wait state, input X0 alone selects contestant 0.
- From the wait state, input X1 alone selects contestant 1.
- If both inputs are high when sampled in the wait state, both LEDs indicate a tie.
- A winner or tie remains stored until reset, regardless of subsequent contestant inputs.

This is a synchronous circuit: inputs affect the stored state on a rising clock edge. With a slow demonstration clock, two presses before the same edge can register as a tie even if they occurred at different times. A short input pulse entirely between rising edges can be missed.

## State transition table

Inputs and state bits are ordered **X1X0** and **Q1Q0**.

| Present state | X1X0 = 00 | X1X0 = 01 | X1X0 = 10 | X1X0 = 11 | Y1Y0 |
| --- | --- | --- | --- | --- | --- |
| A: wait (00) | A | B | C | D | 00 |
| B: contestant 0 wins (01) | B | B | B | B | 01 |
| C: contestant 1 wins (10) | C | C | C | C | 10 |
| D: tie (11) | D | D | D | D | 11 |

```mermaid
stateDiagram-v2
    [*] --> A
    state "Wait / 00" as A
    state "Contestant 0 / 01" as B
    state "Contestant 1 / 10" as C
    state "Tie / 11" as D
    A --> A: 00
    A --> B: 01
    A --> C: 10
    A --> D: 11
    B --> B: Any input
    C --> C: Any input
    D --> D: Any input
    B --> A: Reset
    C --> A: Reset
    D --> A: Reset
```

Reset also keeps state A cleared. Input labels represent X1X0 sampled at a rising clock edge; reset is handled by the flip-flops' asynchronous clear inputs.

## Next-state equations

For a D flip-flop, the value at D becomes the next value of Q on the active clock edge:

```text
D0 = Q0 + X0·Q1'
D1 = Q1 + X1·Q0'
Y0 = Q0
Y1 = Q1
```

Here `+` means OR, `·` means AND, and `'` means NOT. The Q feedback terms preserve a selected result. The complemented opposite state bit prevents the losing contestant from changing the state after a winner has been stored.

### K-map for Q1 next state

Rows and columns use Gray-code order.

| Q1Q0 \\ X1X0 | 00 | 01 | 11 | 10 |
| --- | --- | --- | --- | --- |
| 00 | 0 | 0 | 1 | 1 |
| 01 | 0 | 0 | 0 | 0 |
| 11 | 1 | 1 | 1 | 1 |
| 10 | 1 | 1 | 1 | 1 |

The bottom two rows form the group Q1. The cells in rows 00 and 10, columns 11 and 10, form a wraparound group X1·Q0'. Therefore, **D1 = Q1 + X1·Q0'**.

## Hardware and clock

The prototype uses a breadboard, D flip-flops, combinational logic ICs, two LEDs with series resistors, jumper wires, and an Arduino Uno clock source. The lab specifies 74LS74 positive-edge-triggered D flip-flops. The exact as-built pin-by-pin wiring is not documented here.

The included [Arduino sketch](arduino/clock_generator/clock_generator.ino) is a reference implementation for a nominal 1 Hz clock on digital pin 7. It holds the output high for 500 ms and low for 500 ms, producing one rising edge per second. This is a software-timed demonstration signal, not a measured precision clock.

Connect the clock output to both flip-flop clock inputs and use a common ground between the Arduino and logic circuit. Keep unused asynchronous preset inputs inactive and normally hold active-low clear inputs high; asserting clear low resets both state bits. Check the datasheet for the actual IC before wiring.

The original assignment requests an oscilloscope screenshot of the function-generator waveform and frequency. No such measurement is included in this repository. The Arduino sketch's nominal frequency does not replace an oscilloscope measurement.

## Prototype photos

These photos document the breadboard and Arduino setup. Physical left/right LED positions have not been assigned to contestant numbers in these captions. Still photos alone do not verify input sequence, winner lockout, reset operation, or clock frequency.

![Breadboard with left LED visibly illuminated](images/IMG_4591.jpeg)

![Breadboard with right LED visibly illuminated](images/IMG_4588.jpeg)

![Additional breadboard and Arduino view](images/IMG_4587.jpeg)

![Breadboard with both LEDs visibly illuminated](images/IMG_4586.jpeg)

## Verification status

The design equations and state table describe the required behavior. The attached photos document prototype work, but a complete hardware test sequence has not been recorded here. The following checks remain unconfirmed in this write-up:

| Test | Expected result |
| --- | --- |
| Assert reset | Y1Y0 = 00 |
| Release reset; sample X1X0 = 01 | Y1Y0 = 01 |
| Then assert X1 | Stored result remains 01 |
| Reset; sample X1X0 = 10 | Y1Y0 = 10 |
| Then assert X0 | Stored result remains 10 |
| Reset; sample X1X0 = 11 | Y1Y0 = 11 |
| Change inputs after a tie | Stored result remains 11 |

## Concepts practiced

State-machine design, Karnaugh-map simplification, D flip-flop feedback, synchronous state updates, asynchronous reset, and using a microcontroller as a clock source for external digital logic.

## Source

Design requirements and the supplied D0 equation are from the CDA 3201L Lab #6 handout, “Sequential Circuits – Game Show Circuit.” The D1 equation and K-map above follow from its state table.
