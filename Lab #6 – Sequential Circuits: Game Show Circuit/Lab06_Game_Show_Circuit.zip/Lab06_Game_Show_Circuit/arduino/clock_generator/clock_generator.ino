// Reference Arduino Uno clock source for the external game show circuit.
// This sketch generates the clock only; external logic stores the winner.
// Nominal period: 500 ms HIGH + 500 ms LOW = 1 second (1 Hz).
// Software overhead adds a small amount to the period.

const byte CLOCK_PIN = 7;
const unsigned long HALF_PERIOD_MS = 500;

void setup() {
  digitalWrite(CLOCK_PIN, LOW);
  pinMode(CLOCK_PIN, OUTPUT);
}

void loop() {
  digitalWrite(CLOCK_PIN, HIGH);
  delay(HALF_PERIOD_MS);
  digitalWrite(CLOCK_PIN, LOW);
  delay(HALF_PERIOD_MS);
}
